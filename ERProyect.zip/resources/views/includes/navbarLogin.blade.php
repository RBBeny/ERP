<link rel="stylesheet" href="{{ asset('css/navbar.css') }}" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />     
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">  
<input type="checkbox" id="checkk">
        <div class="cabezera">
            <div class="contentenidoCabezera">
           <br>
           
           <div class="Izquierda_area">
               <h3>ERP <span>Jarcie</span></h3>
           </div>
    
            </div>
        </div>
     