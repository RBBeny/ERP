@extends('layouts.plantilla')

@section('titulo','Home Cobranza')


@section('content')

@include('includes.navbarCobranza')
<div class="contenedor">
<br>
<br>
<br>
    <h1>"AL FINAL DE LOS DOS QUIEN PIERDE MAS SERA TU POR QUE YO,YO PUEDO QUERER A MUCHAS COMO TE QUIZE A TI PERO A TI JAMAS TE QUERRA NADIE COMO YO LO HICE"</h1>
</div>

@endsection

