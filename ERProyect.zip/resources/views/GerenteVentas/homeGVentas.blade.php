@extends('layouts.plantilla')

@section('titulo','Home Gerente Ventas')


@section('content')
@include('includes.navbarGVentas')


@endsection
