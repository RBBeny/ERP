@extends('layouts.plantilla')

@section('titulo','Home Ventas')


@section('content')
@include('includes.navbar')


@endsection

