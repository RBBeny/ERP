@extends('layouts.plantilla')

@section('titulo','Home Administrador')


@section('content')
@include('includes.navbarAdministrador')


@endsection

