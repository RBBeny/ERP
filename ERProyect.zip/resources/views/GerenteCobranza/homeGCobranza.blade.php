@extends('layouts.plantilla')

@section('titulo','Home Gerente Cobranza')


@section('content')
@include('includes.navbarGCobranza')


@endsection
