

@extends('layouts.plantilla')

@section('titulo','prueba')

@section('content')

@include('includes.navbar')

@endsection