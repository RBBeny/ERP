@extends('layouts.plantilla')

@section('titulo','Home Recursos Humanos')


@section('content')
@include('includes.navbarRh')
<h1>cobradoredit.blade.php</h1>


@endsection

