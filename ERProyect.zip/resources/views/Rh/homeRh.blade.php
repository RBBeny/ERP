@extends('layouts.plantilla')

@section('titulo','Home Recursos Humanos')


@section('content')
@include('includes.navbarRh')


@endsection

