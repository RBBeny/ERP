<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\CobranzaController;

Route:: get('/homeCobranza', [CobranzaController::class, 'home']);
Route:: get('/ClientesCobranza',[CobranzaController::class, 'clientes']);
Route:: get('/PagosCobranza',[CobranzaController::class, 'PagosCobranza']);
Route:: get('/Recibos',[CobranzaController::class, 'Recibos']);
Route:: get('/ClienteCobranza',[CobranzaController::class, 'ClienteCobranza']);
Route:: get('/TablasClientesC',[CobranzaController::class, 'TablasClientesC']);
Route::post('insertarPago',[CobranzaController::class,'insertarPago'])->name('insertarPago.insertarPago');
Route:: get('/VerCliente/{id}', [CobranzaController::class, 'cliente']);
Route::get('delete/{cvePago}',[CobranzaController::class,'eliminarPago'])->name('eliminarPago');

