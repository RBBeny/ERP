

<?php $__env->startSection('titulo','Clientes Cobranza'); ?>
<?php $__env->startSection('css'); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" type="text/css" rel="stylesheet">

<link href="<?php echo e(asset('css/Ventas/clientesVentas.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.navbarCobranza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="contenedor">
    <h1>Clientes</h1>
    <div class="tablaclientes">

        <table id="clienteVentas" class="table display table-striped table-bordered nowrap" style="width:100%">
            <thead>
                <tr>
                    <th scope="col">N°Sol</th>
                    <th scope="col">N°Cont</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Domicilio</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Estatus</th>
                    <th scope="col">Ver Cliente</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cliente-> cveSolicitud); ?></td>
                    <td><?php echo e($cliente-> cveContrato); ?></td>
                    <td><?php echo e($cliente->nomCliente); ?> <?php echo e($cliente-> apellidoPaternoCliente); ?> <?php echo e($cliente-> apellidoMaternoCliente); ?></td>
                    <td><?php echo e($cliente-> nomEstado); ?>, <?php echo e($cliente-> nomMunicipio); ?>, <?php echo e($cliente-> nomColonia); ?>, <?php echo e($cliente-> calleCliente); ?> #: <?php echo e($cliente-> numeroExteriorCasaCliente); ?></td>
                    <td><?php echo e($cliente-> telefonoCliente); ?></td>
                    <td><?php echo e($cliente-> nomEstatusContrato); ?></td>
                    <td ><a href="/VerCliente/<?php echo e($cliente-> cveCliente); ?>"> <i class="far fa-eye fa-lg"></i></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
</div>
<?php $__env->startSection('js'); ?>

<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {
        $('#clienteVentas').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/Cobranza/ClienteCobranza.blade.php ENDPATH**/ ?>