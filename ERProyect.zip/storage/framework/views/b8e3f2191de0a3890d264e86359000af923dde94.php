

<?php $__env->startSection('titulo','Pagos Cobranza'); ?>
<?php $__env->startSection('css'); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" type="text/css" rel="stylesheet">

<link href="<?php echo e(asset('css/Ventas/clientesVentas.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.navbarCobranza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="contenedor">
<div id="alerts">
   </div>    
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="/homeCobranza">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Ver Pagos                     </li>
  </ol>
</nav>
<br>
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary"data-bs-toggle="modal" data-bs-target="#AgregarPagos">
Agregar Pagos
</button>
<div class="modal fade" id="AgregarPagos" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"  data-target=".bd-example-modal-lg" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Agregar Pagos</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
  

      <form>
<!-- aqui-->
<?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>

  <div class="form-group">
    <?php echo csrf_field(); ?>
    <label for="InputCveContrato">Numero de Contrato</label>
    <?php $__errorArgs = ['cveContrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <br>
    <small>*<?php echo e($message); ?></small>
    <br>
   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="number" class="form-control" id="cveContrato" placeholder="Numero de Contrato" value="cveContrato" name="cveContrato" required>

  </div>
  <div class="form-group">
    <label for="InputNombre">Nombre del Cliente</label>
    <input type="text" class="form-control" id="InputNombre" placeholder="Nombre" readonly >
  </div>
  <div class="form-group">
    <label for="InputFecha">Fecha</label>
    <input type="date" class="form-control" id="fechaPago"  value="fechaPago" name="fechaPago" required>
  </div>
  <div class="form-group">
    <label for="InputCvePago">Clave Pago</label>
    <input type="number" class="form-control" id="cvePago" placeholder="Clave de Pago"  value="cvePago" name="cvePago" required>
  </div>
  <div class="form-group">
    <label for="InputCantPago">Cantidad</label>
    <input type="number" class="form-control" id="cantidadPago" placeholder="Cantidad" value="cantidadPago" name="cantidadPago"  required>
  </div>
  <div class="form-group">
    <label for="InputCveCobrador">Nombre Cobrador</label>
  <select class="form-select" id="cveCobrador" placeholder="Clave Cobrador" value="cveCobrador" name="cveCobrador aria-label="Default select example">
  <option selected>Cobredores</option>
  <?php $__currentLoopData = $cobradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cobrador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($cobrador->cveCobrador); ?> "><?php echo e($cobrador->nombreCobrador); ?> <?php echo e($cobrador-> apellidoPaternoCobrador); ?> <?php echo e($cobrador-> apellidoMaternoCobrador); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
  <button type="button"  data-bs-dismiss="modal" aria-label="Close" class="btn btn-danger">Cancelar</button>
  <button type="submit" id="btnGuardarPago" class="btn btn-success" >Guardar</button>

</form>
      </div>

    </div>
  </div>
</div>
<br>
<br>
<div>
                    <table id="pagos"  class="table display table-striped table-bordered nowrap" style="width:100%">
                        <thead>
                            <tr>
                            <th scope="col">Numero de Pago</th>
                            <th scope="col">Numero del Contrato</th>
                            <th scope="col">Forma de pago</th>
                            <th scope="col">Pago</th>
                            <th scope="col">Restante</th>
                            <th scope="col">Fecha</th>
                            <th scope="col">Cobrador</th>
                            <th scope="col">Elimimar</th>

                            </tr>
                        </thead>
                        <tbody>
                          
                        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pago-> cvePago); ?></td>
                                <td><?php echo e($pago-> cveContrato); ?></td>
                                <td><?php echo e($pago-> nomFormaPago); ?></td>
                                <td><?php echo e($pago-> cantidadPago); ?></td>
                                <td><?php echo e($pago-> restantePaquete); ?></td>
                                <td><?php echo e($pago-> fechaPago); ?></td>
                                <td><?php echo e($pago->nombreCobrador); ?> <?php echo e($pago-> apellidoPaternoCobrador); ?> <?php echo e($pago-> apellidoMaternoCobrador); ?></td>
                                <td>
                                  <form name="form-data" id="form-data" action="<?php echo e(route('eliminarPago',$pago->cvePago)); ?>" method="POST">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field ()); ?>

                                    <a href="#" class="btn-delete btn btn-danger btn-sm" id="<?php echo e($pago->cvePago); ?>" title="Borrar Pago">
                                      <i class="zmdi zmdi-delete zmdi-hc-lg"></i>
                                      Eliminar
                                    </a>

                                  </form>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
</div>
<?php $__env->startSection('js'); ?>
<script>
$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})</script>

<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js" type="text/javascript"></script>
<script src="<?php echo e(asset('js/components/alerts.js')); ?>" charset="utf8" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo e(asset('js/Ventas/verCliente.js')); ?>" type="text/javascript"></script>
<script>
$(document).ready(function () {
    $('#pagos').DataTable({
    pageLength : 5,
    lengthMenu: [[5, 10, 20], [5, 10, 20]],
    language: {
      "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
    }
    });
});
</script>
<script>
  $(document).ready(function (){
    $('contenMsjs').hide();

    $(".btn-delete").click(function (e){
      e.preventDefault();
      var id = $(this).attr("id");

      var form  =$(this).parents("form");
      var url   =form.attr('action');
        $.ajax({
          type: "DELETE",
          url: url,
          data: $("#form-data").serialize(),
          success: function(data)
          {
            $("#contenMsjs").show();
            $('#msj').html(datamensaje);
            $('#tpagoAll').html(data.totalprofesores);
            $("#registro" + id).hide('slow');
          setTimeout(function(){
            $("#contenMsjs").fadeOut("slow");
          },4000);            
          }
        });
    });
  });
</script>
<script>
    $(document).ready(function(){
        $('#clienteVentas').DataTable();

   $('#btnGuardarPago').click(function(){
      
   var cvePago = $('#cvePago').val();
   var fechaPago = $('#fechaPago').val();
   var cantidadPago = $('#cantidadPago').val();
   var cveContrato = $('#cveContrato').val();
   var cveCobrador = $('#cveCobrador').val();

   var _token = $("input[name=_token]").val();
 
   $.ajax({
       type:"POST",
       url:"<?php echo e(route('insertarPago.insertarPago')); ?>",
       data:{
           cvePago:cvePago,
           fechaPago:fechaPago,
           cantidadPago:cantidadPago,
           cveContrato:cveContrato,
           cveCobrador:cveCobrador,
           _token:_token
       },
       success:function(res){
               console.log('Se ha creado un registro correctamente');
               alertSucces("Se agrego el pago");
               document.getElementById('#nomEstado');
            },
        error:function(res){
            alertDanger("No se agrego el pago")
            console.log("No se ha hecho el registro");
        }            
   });
   return false;
});


});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/Cobranza/PagosCobranza.blade.php ENDPATH**/ ?>