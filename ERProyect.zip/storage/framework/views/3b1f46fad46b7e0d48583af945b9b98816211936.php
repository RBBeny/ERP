
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/css/bootstrap.min.css" rel="stylesheet">

        <!-- Font Awesome -->
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">

    <title>Index</title>
</head>
<body>
<header>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Logo</a>
  </div>
</nav>
</header>
<div class="mt-4 p-5 bg-primary text-white rounded">
  <h1>Este proyecto tiene boststrap5</h1>
  <p>Lorem ipsum...</p>
</div>


</body>
<script src="/js/bootstrap.bundle.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/jquery-3.6.0.min.js"></script>

</html><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/welcome.blade.php ENDPATH**/ ?>