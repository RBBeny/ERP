

<?php $__env->startSection('titulo','Clientes Ventas'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" type="text/css" rel="stylesheet">

<link href="<?php echo e(asset('css/Ventas/verCliente.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="contenedor">
<h1>Información del cliente</h1>
    <div class="contenedorInfo">
        <ul class="tabs">
            <li> <a href="#tab1"><span><i class="fas fa-user fa-lg"></i></span></a> </li>
            <li> <a href="#tab2"><span class="tab-text">Domicilio</span></a> </li>
            <li> <a href="#tab3"><span class="tab-text">Cuenta</span></a> </li>
            <li> <a href="#tab4"><span class="tab-text">Pagos</span></a> </li>
        </ul>
        <div class="secciones">
            <article id="tab1">
                <div class="DatosCliente">
                    <div class="row">
                        <div class="form-field col-lg-4">
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label for="NoContrato" class="label">N° Contrato</label>
                                <input type="text" class="input-text" value="<?php echo e($cliente->cveContrato); ?>" id="NoContrato" readonly>
                           
                        </div>
                        <div class="form-field col-lg-4">
                            <label for="NoSolicitud" class="label">N° Solicitud</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->cveSolicitud); ?>" id="NoSolicitud" readonly>
                        </div>
                        <div class="form-field col-lg-4 ">
                            <label for="Estatus" class="label">Estatus</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->nomEstatusContrato); ?>" id="Estatus" readonly>
                        </div>
                    </div>
                    <div>
                        <div class="form-field col-lg-7">
                            <label for="Nombre" class="label">Nombre</label>
                            <input type="text" class="input-text-Nombre" id="Nombre" value="<?php echo e($cliente->nomCliente); ?> <?php echo e($cliente->apellidoPaternoCliente); ?> <?php echo e($cliente->apellidoMaternoCliente); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-field-celular col-lg-5">
                            <label for="NoCelular" class="label">N° Celular</label>
                            <input type="text" class="input-text-celular" id="NoCelular"  value="<?php echo e($cliente->telefonoCliente); ?>" readonly>
                        </div>
                        <div class="form-field-celular col-lg-3">
                            <input type="text" class="input-text-celular" id="NoCelular2" value="<?php echo e($cliente->telefonoDosCliente); ?>" readonly>
                        </div>
                        <div class="form-field-celular col-lg-3 ">
                            <input type="text" class="input-text-celular" id="NoCelular3" value="<?php echo e($cliente->telefonoTresCliente); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-field-DosColumnas col-lg-5">
                            <label for="EstadoCivil" class="label">Estado civil</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->estadoCivilCliente); ?>" id="EstadoCivil" readonly> 
                        </div>
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="FechaNacimiento" class="label">Fecha nacimiento</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->fechaNacimientoCliente); ?>" id="FechaNacimiento" readonly>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               
            </article>
            <article id="tab2">
                <div class="domicilioCliente">
                    <center>
                        <h2>Domicilio del cliente</h2>
                    </center>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="form-field-DosColumnas col-lg-5">
                            <label for="Estado" class="label">Estado</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->nomEstado); ?>" id="Estado" readonly>
                        </div>
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="Municipio" class="label">Municipio</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->nomMunicipio); ?>" id="Municipio" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="Colonia" class="label">Colonia</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->nomColonia); ?>" id="Colonia" readonly>
                        </div>
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="Calle" class="label">Calle</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->calleCliente); ?>" id="Calle" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-field col-lg-4">
                            <label for="NoExt" class="label">N° Ext</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->numeroExteriorCasaCliente); ?>" id="NoExt" readonly>
                        </div>
                        <div class="form-field col-lg-4">
                            <label for="NoInt" class="label">N° Int</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->numeroInteriorCasaCliente); ?>" id="NoInt" readonly>
                        </div>
                        <div class="form-field col-lg-4 ">
                            <label for="cp" class="label">C.P.</label>
                            <input type="text" class="input-text" id="cp">
                        </div>
                    </div>
                    <div>
                        <div class="form-field col-lg-9">
                            <label for="EntreCalles" class="label">Entre calles</label>
                            <input type="text" class="input-text-columna" value="<?php echo e($cliente->entreCallesCliente); ?>" id="EntreCalles" readonly>
                        </div>
                    </div>
                    <div>
                        <div class="form-field col-lg-9">
                            <label for="referencias" class="label">Referencias</label>
                            <input type="text" class="input-text-columna" value="<?php echo e($cliente->referenciasCasaCliente); ?>" id="referencias" readonly>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="domicilioClienteCobro">
                    <center>
                        <h2>Domicilio de cobro del cliente</h2>
                    </center>
                    <div class="row">
                        <div class="form-field-DosColumnas col-lg-6">
                        <?php $__currentLoopData = $cobros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label for="Municipio" class="label">Municipio</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cob-> nomMunicipio); ?>" id="Municipio" readonly>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="Colonia" class="label">Colonia</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cob-> nomColonia); ?>" id="Colonia" readonly>
                        </div>
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="Calle" class="label">Calle</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->calleClienteCobro); ?>" id="Calle" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-field col-lg-4">
                            <label for="NoExt" class="label">N° Ext</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->numeroExteriorCasaClienteCobro); ?>" id="NoExt" readonly>
                        </div>
                        <div class="form-field col-lg-4">
                            <label for="NoInt" class="label">N° Int</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->numeroInteriorCasaClienteCobro); ?>" id="NoInt" readonly>
                        </div>
                        <div class="form-field col-lg-4 ">
                            <label for="cp" class="label">C.P.</label>
                            <input type="text" class="input-text" id="cp">
                        </div>
                    </div>
                    <div>
                        <div class="form-field col-lg-9">
                            <label for="EntreCalles" class="label">Entre calles</label>
                            <input type="text" class="input-text-columna" value="<?php echo e($cliente->entreCallesClienteCobro); ?>" id="EntreCalles" readonly>
                        </div>
                    </div>
                    <div>
                        <div class="form-field col-lg-9">
                            <label for="referencias" class="label">Referencias</label>
                            <input type="text" class="input-text-columna" value="<?php echo e($cliente->referenciasCasaClienteCobro); ?>" id="referencias" readonly>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </article>
            <article id="tab3">
                <div class="datosCuenta">
                    <center>
                        <h2>Datos Cuenta</h2>
                    </center>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="form-field col-lg-4">
                            <label for="NoContrato" class="label">N° Contrato</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->cveContrato); ?>"  id="NoContrato" readonly>
                        </div>
                        <div class="form-field col-lg-4">
                            <label for="NoSolicitud" class="label">N° Solicitud</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->cveSolicitud); ?>" id="NoSolicitud" readonly>
                        </div>
                        <div class="form-field col-lg-4 ">
                            <label for="Costo" class="label">Costo</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->costoPaquete); ?>" id="Costo" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-field col-lg-4">
                            <label for="Adeudo" class="label">Adeudo</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->restantePaquete); ?>" id="Adeudo" readonly>
                        </div>
                        <div class="form-field-D col-lg-5">
                            <label for="liquidado" class="label">Deuda saldada</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->totalPagado); ?>" id="liquidado" readonly>
                        </div>
                        <div class="form-field-f col-lg-4 ">
                            <label for="formaPago" class="label">Forma pago</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->nomFormaPago); ?>" id="formaPago" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="fechaAfilación" class="label">Fecha de afilación</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->fechaEmision); ?>" id="fechaAfilación" readonly>
                        </div>
                        <div class="form-field-DosColumnas col-lg-6">
                            <label for="Vendedor" class="label">Vendedor</label>
                            <input type="text" class="input-text-DosColumnas" value="<?php echo e($cliente->nombreVendedor); ?> <?php echo e($cliente->apellidoPaternoVendedor); ?> <?php echo e($cliente->apellidoMaternoVendedor); ?>" id="Vendedor" readonly>
                        </div>
                    </div>
                    <div>
                        <div class="form-field col-lg-6">
                            <label for="Cobrador" class="label">Cobrador</label>
                            <input type="text" class="input-text-columna" value="<?php echo e($cliente->nombreCobrador); ?> <?php echo e($cliente->apellidoPaternoCobrador); ?> <?php echo e($cliente->apellidoMaternoCobrador); ?>" id="Cobrador" readonly>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </article>
            <article id="tab4">
                <div class="pagos">
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="form-field col-lg-4">
                            <label for="NoContrato" class="label">Estatus</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->nomEstatusContrato); ?>" id="Estatus" readonly>
                        </div>
                        <div class="form-field col-lg-4">
                            <label for="NoSolicitud" class="label">Total pagado</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->totalPagado); ?>" id="TotalPagado" readonly>
                        </div>
                        <div class="form-field col-lg-4 ">
                            <label for="Estatus" class="label">Adeudo</label>
                            <input type="text" class="input-text" value="<?php echo e($cliente->restantePaquete); ?>" id="Adeudo" readonly>
                        </div>
                    </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div>
                    <table id="pagos" class="display compact" style="width:100%">
                        <thead>
                            <tr>
                                <th>Folio</th>
                                <th>Fecha</th>
                                <th>Monto</th>
                                <th>cobrador</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pago-> cvePago); ?></td>
                                <td><?php echo e($pago-> fechaPago); ?></td>
                                <td><?php echo e($pago-> cantidadPago); ?></td>
                                <td><?php echo e($pago->nombreCobrador); ?> <?php echo e($pago-> apellidoPaternoCobrador); ?> <?php echo e($pago-> apellidoMaternoCobrador); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </article>
        </div>

    </div>
</div>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo e(asset('js/Ventas/verCliente.js')); ?>" type="text/javascript"></script>
<script>
$(document).ready(function () {
    $('#pagos').DataTable({
    pageLength : 5,
    lengthMenu: [[5, 10], [5, 10]],
    language: {"url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"}
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/Ventas/verClienteVentas.blade.php ENDPATH**/ ?>