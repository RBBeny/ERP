

<?php $__env->startSection('titulo','Usuarios Cobranza'); ?>
<?php $__env->startSection('css'); ?>

<link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" type="text/css" rel="stylesheet">


<link href="<?php echo e(asset('css/Ventas/clientesVentas.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.navbarGCobranza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="contenedor">
<nav aria-label="breadcrumb" style="padding: 10px;">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="/homeCobranza">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Ver Usuarios</li>
  </ol>
</nav>    

<div class="tablaclientes" >

        <table id="clienteVentas" class="table display table-striped table-bordered nowrap" style="width:100%">
            <thead>
                <tr>
                    <th scope="col">Numero de Pago</th>
                    <th scope="col">Numero del Contrato</th>
                    <th scope="col">Forma de pago</th>
                    <th scope="col">Pago</th>
                    <th scope="col">Restante</th>
                    <th scope="col">Fecha</th>
                    <th scope="col">Cobrador</th>   
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pago-> cvePago); ?></td>
                    <td><?php echo e($pago-> cveContrato); ?></td>
                    <td><?php echo e($pago-> nomFormaPago); ?></td>
                    <td><?php echo e($pago-> cantidadPago); ?></td>
                    <td><?php echo e($pago-> restantePaquete); ?></td>
                    <td><?php echo e($pago-> fechaPago); ?></td>
                    <td><?php echo e($pago->nombreCobrador); ?> <?php echo e($pago-> apellidoPaternoCobrador); ?> <?php echo e($pago-> apellidoMaternoCobrador); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
      
    </div>

</div>

<?php $__env->startSection('js'); ?>
<script src="js/GerenteCobranza/agregarUsuario.js"></script>
<script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js" type="text/javascript"></script>
<script type="text/javascript">
    

$(document).ready(function() {
    $('#clienteVentas').DataTable({
        language: {
      "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
    }
    });
    

});
    
</script>


<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/GerenteCobranza/GenerarReporte.blade.php ENDPATH**/ ?>