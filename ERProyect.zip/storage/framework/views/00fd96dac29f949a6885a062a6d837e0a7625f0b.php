

<?php $__env->startSection('titulo','Home Recursos Humanos'); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.navbarRh', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/Rh/homeRh.blade.php ENDPATH**/ ?>