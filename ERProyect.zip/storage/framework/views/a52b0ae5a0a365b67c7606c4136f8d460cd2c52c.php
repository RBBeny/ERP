

<?php $__env->startSection('titulo','Home Cobranza'); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.navbarCobranza', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="contenedor">
<br>
<br>
<br>
    <h1>"AL FINAL DE LOS DOS QUIEN PIERDE MAS SERA TU POR QUE YO,YO PUEDO QUERER A MUCHAS COMO TE QUIZE A TI PERO A TI JAMAS TE QUERRA NADIE COMO YO LO HICE"</h1>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/Cobranza/homeCobranza.blade.php ENDPATH**/ ?>