

<?php $__env->startSection('titulo','Home Ventas'); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/Ventas/agregarClientes.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php $estados = app('App\Services\Estados'); ?>
<?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="contenedor">
    <div class="formulario__mensaje" id="formulario__mensaje" >
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>LLenar todos los campos </strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>

            <div class="formulario__mensaje-exito" id="formulario__mensaje-exito">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Se agrego el registro correctamente!</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>

            <div id="alerts">
            </div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item "><a id="url" href="/HomeVentas">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Agregar cliente</li>
                </ol>
            </nav>
            <div class="contenedorN2">
                <div class="col-lg-6 col-12 mx-auto">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?>

                </div>
                <div class="contenedorStep">

                    <div class="step-row">
                        <div id="progress"></div>
                        <div class="step-col"><small>Parte 1</small></div>
                        <div class="step-col"><small>Parte 2</small></div>
                        <div class="step-col"><small>Parte 3</small></div>
                        <div class="step-col"><small>Parte 4</small></div>
                    </div>
                    <div class="contenedorN3">

                        <form class="col-12 formulario" method="POST" id="formulario" action="<?php echo e(route('insertarCliente.insertarCliente')); ?>">
                            <?php echo csrf_field(); ?>
                            <div id="cnp1" class="contenedorN3parte1">
                                <center>
                                    <h2>Datos del cliente</h1>
                                </center>
                                <div class="form-row">
                                    <div class="form-group col-md-5 " id="grupo__noSolicitud">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="formulario__input form-control  <?php $__errorArgs = ['noSolicitud'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="noSolicitud" name="noSolicitud" placeholder="*N° solicitud" value="<?php echo e(old('noSolicitud')); ?>" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El Numero de solicitud tiene que ser de 1 a 8 dígitos y solo puede contener numeros</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>

                                        <?php $__errorArgs = ['noSolicitud'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group col-md-5" id="grupo__noContrato">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['noContrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="noContrato" name="noContrato" placeholder="*N° contrato" value="<?php echo e(old('noContrato')); ?>" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El Numero de contrato tiene que ser de 1 a 8 dígitos, solo puede contener una letra y numeros</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>
                                        <?php $__errorArgs = ['noContrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-7" id="grupo__nombreCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['nombreCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nombreCliente" name="nombreCliente" value="<?php echo e(old('nombreCliente')); ?>" placeholder="*Nombre" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El nombre del cliente tiene que ser de maximo 30 caracteres y solo puede contener letras</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>
                                        <?php $__errorArgs = ['nombreCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6" id="grupo__apellidoPaternoCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input  <?php $__errorArgs = ['apellidoPaternoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="apellidoPaternoCliente" name="apellidoPaternoCliente" value="<?php echo e(old('apellidoPaternoCliente')); ?>" placeholder="*Apellido Paterno" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El apellido del cliente tiene que ser de maximo 30 caracteres y solo puede contener letras</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>
                                        <?php $__errorArgs = ['apellidoPaternoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6" id="grupo__apellidoMaternoCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['apellidoMaternoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="apellidoMaternoCliente" name="apellidoMaternoCliente" value="<?php echo e(old('apellidoMaternoCliente')); ?>" placeholder="*Apellido Materno" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El apellido del cliente tiene que ser de maximo 30 caracteres y solo puede contener letras</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>
                                        <?php $__errorArgs = ['apellidoMaternoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6" id="grupo__numeroTelefonoCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['numeroTelefonoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="numeroTelefonoCliente" name="numeroTelefonoCliente" value="<?php echo e(old('numeroTelefonoCliente')); ?>" placeholder="*N° telefono" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El Numero de telefono tiene que ser de 10 a 11 dígitos y solo puede contener numeros</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>
                                        <?php $__errorArgs = ['numeroTelefonoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6" id="grupo__numeroTelefonoDosCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['numeroTelefonoDosCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="numeroTelefonoDosCliente" name="numeroTelefonoDosCliente" value="<?php echo e(old('numeroTelefonoDosCliente')); ?>" placeholder="N° telefono 2">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El Numero de telefono tiene que ser de 10 a 11 dígitos y solo puede contener numeros</p>

                                        <?php $__errorArgs = ['numeroTelefonoDosCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6" id="grupo__numeroTelefonoTresCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['numeroTelefonoTresCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="numeroTelefonoTresCliente" name="numeroTelefonoTresCliente" value="<?php echo e(old('numeroTelefonoTresCliente')); ?>" placeholder="N° telefono 3">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El Numero de telefono tiene que ser de 10 a 11 dígitos y solo puede contener numeros</p>

                                        <?php $__errorArgs = ['numeroTelefonoTresCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row ">
                                    <div class="form-group col-md-5" id="grupo__estadoCivilCliente">
                                        <div class="formulario__grupo-input">
                                            <input class="form-control formulario__input <?php $__errorArgs = ['estadoCivilCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="estadoCivilCliente" name="estadoCivilCliente" value="<?php echo e(old('estadoCivilCliente')); ?>" placeholder="Estado civil">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">Tiene que ser de maximo 12 caracteres y solo puede contener letras</p>
                                       
                                        <?php $__errorArgs = ['estadoCivilCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row form-inline">
                                    <div class="col-md-6 mb-3">
                                        <label for="fechaNacimiento">Fecha de nacimiento</label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['fechaNacimientoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fechaNacimientoCliente" value="<?php echo e(old('fechaNacimientoCliente')); ?>" name="fechaNacimientoCliente">
                                        <?php $__errorArgs = ['fechaNacimientoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="siguienteP2" class="btn btn-primary"><i class="fa-solid fa-circle-right"></i> Siguiente</button>
                                </div>
                            </div>
                            
                            <div id="cnp2" class="contenedorN3parte2">
                                <center>
                                    <h2>Domicilio del cliente</h1>
                                </center>


                                <div class="form-row form-inline">
                                    <div class="col-md-5 mb-3" id="grupo__cveEstadoCliente">
                                    <div class="formulario__grupo-input">
                                        <select id="estado" class="form-control formulario__input <?php $__errorArgs = ['cveEstadoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cveEstadoCliente" value="<?php echo e(old('cveEstadoCliente')); ?>" required>

                                            <?php $__currentLoopData = $estados->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($index); ?>" <?php echo e(old('cveEstadoCliente')  == $index ? 'selected' :''); ?>>
                                                <?php echo e($estado); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">La opción no es valida</p>
                                        
                                        <?php $__errorArgs = ['cveEstadoCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-2" id="grupo__cveMunicipioCliente" >
                                    
                                        <select id="municipio" data-old="<?php echo e(old('cveMunicipioCliente')); ?>" class="form-control  <?php $__errorArgs = ['cveMunicipioCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cveMunicipioCliente')); ?>" name="cveMunicipioCliente" required>

                                        </select>
                                      
                                        
                                        <p class="formulario__input-error">La opción no es valida</p>
                                        <button id="abrir-popupMunicipio" type="button" class="agregarElemento"> <i class="fa-solid fa-circle-plus fa-lg"></i></button>
                                        <?php $__errorArgs = ['cveMunicipioCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row form-inline">
                                    <div class="col-md-7 mb-3" id="grupo__cveColoniaCliente">
                                   
                                        <select id="colonia" name="cveColoniaCliente" data-old="<?php echo e(old('cveColoniaCliente')); ?>" value="<?php echo e(old('cveColoniaCliente')); ?>" class="form-control  <?php $__errorArgs = ['cveColoniaCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                                        </select>
                                        
                                     
                                        <p class="formulario__input-error">La opción no es valida</p>
                                        <button id="abrir-popupColonia" type="button" class="agregarElemento"> <i class="fa-solid fa-circle-plus fa-lg"></i></button>
                                        <?php $__errorArgs = ['cveColoniaCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="col-md-6 mb-4" id="grupo__calleCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['calleCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="calleCliente" name="calleCliente" value="<?php echo e(old('calleCliente')); ?>" placeholder="*Calle" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">la calle tiene que ser de maximo 30 caracteres, solo puede contener letras y numeros</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>
                                    </div>
                                    <?php $__errorArgs = ['calleCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-4" id="grupo__numeroExteriorCasaCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['numeroExteriorCasaCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="numeroExteriorCasaCliente" value="<?php echo e(old('numeroExteriorCasaCliente')); ?>" id="numeroExteriorCasaCliente" placeholder="*N° ext" required>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El Numero de la casa tiene que ser de maximo 10 dígitos, solo puede contener numeros y letras</p>
                                        <p class="formulario__input-error-required">Este campo es requirido</p>
                                        <?php $__currentLoopData = $errors->get('numeroExteriorCasaCliente'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($error); ?></strong>
                                        </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="form-group col-md-4" id="grupo__numeroInteriorCasaCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['numeroInteriorCasaCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="numeroInteriorCasaCliente" value="<?php echo e(old('numeroInteriorCasaCliente')); ?>" id="numeroInteriorCasaCliente" placeholder="N° int">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">El Numero de la casa tiene que ser de maximo 10 dígitos, solo puede contener numeros y letras</p>

                                        <?php $__errorArgs = ['numeroInteriorCasaCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col-md-9" id="grupo__entreCallesCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['entreCallesCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('entreCallesCliente')); ?>" name="entreCallesCliente" id="entreCallesCliente" placeholder="Entre calles">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">Tiene que ser de maximo 50 caracteres, solo puede contener letras y numeros</p>
                                        <?php $__errorArgs = ['entreCallesCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-9" id="grupo__referenciasCasaCliente">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['referenciasCasaCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('referenciasCasaCliente')); ?>" name="referenciasCasaCliente" id="referenciasCasaCliente" placeholder="Referencias del domicilio">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">Tiene que ser de maximo 50 caracteres y solo puede contener letras</p>

                                        <?php $__errorArgs = ['referenciasCasaCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-row form-inline">
                                    <input type="checkbox" id="check" value="1" onchange="javascript:showContent()" />
                                    <p> ¿El domicilio de cobro es diferente al del cliente?</p>
                                </div>
                                <div id="clienteCobro" style="display: none;">
                                    <div class="form-row form-inline">

                                        <div class="col-md-6 mb-3" id="grupo__cveMunicipioClienteCobro">
                                        <div class="formulario__grupo-input">
                                            <select id="municipioCobro" name="cveMunicipioClienteCobro" value="<?php echo e(old('cveMunicipioClienteCobro')); ?>" data-old="<?php echo e(old('cveMunicipioClienteCobro')); ?>" class="form-control formulario__input <?php $__errorArgs = ['cveMunicipioClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="">Municipio...</option>
                                            </select>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                            </div>
                                            <p class="formulario__input-error">La opción no es valida</p>
                                            <?php $__errorArgs = ['cveMunicipioClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-row form-inline">
                                        <div class="col-md-5 mb-3" id="grupo__cveColoniaClienteCobro">
                                        <div class="formulario__grupo-input">
                                            <select id="coloniaCobro" name="cveColoniaClienteCobro" value="<?php echo e(old('cveColoniaClienteCobro')); ?> " data-old="<?php echo e(old('cveColoniaClienteCobro')); ?>" class="form-control formulario__input <?php $__errorArgs = ['cveColoniaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="">Colonia...</option>
                                            </select>
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                            </div>
                                            <p class="formulario__input-error">La opción no es valida</p>
                                            <?php $__errorArgs = ['cveColoniaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-7" id="grupo__calleClienteCobro">
                                            <div class="formulario__grupo-input">
                                                <input type="text" class="form-control formulario__input  <?php $__errorArgs = ['calleClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="calleClienteCobro" value="<?php echo e(old('calleClienteCobro')); ?>" id="calleClienteCobro" placeholder="*Calle">
                                                <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                            </div>
                                            <p class="formulario__input-error">la calle tiene que ser de maximo 30 caracteres, solo puede contener letras y numeros</p>

                                            <?php $__errorArgs = ['calleClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-4" id="grupo__numeroExteriorCasaClienteCobro">
                                            <div class="formulario__grupo-input">
                                                <input type="text" class="form-control formulario__input  <?php $__errorArgs = ['numeroExteriorCasaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="numeroExteriorCasaClienteCobro" value="<?php echo e(old('numeroExteriorCasaClienteCobro')); ?>" name="numeroExteriorCasaClienteCobro" placeholder="*N° ext">
                                                <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                            </div>
                                            <p class="formulario__input-error">El Numero de la casa tiene que ser de maximo 10 dígitos, solo puede contener numeros y letras</p>

                                            <?php $__errorArgs = ['numeroExteriorCasaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-4" id="grupo__numeroInteriorCasaClienteCobro">
                                            <div class="formulario__grupo-input">
                                                <input type="text" class="form-control formulario__input  <?php $__errorArgs = ['numeroInteriorCasaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('numeroInteriorCasaClienteCobro')); ?>" id="numeroInteriorCasaClienteCobro" name="numeroInteriorCasaClienteCobro" placeholder="*N° int">
                                                <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                            </div>
                                            <p class="formulario__input-error">El Numero de la casa tiene que ser de maximo 10 dígitos, solo puede contener numeros y letras</p>

                                            <?php $__errorArgs = ['numeroInteriorCasaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-7" id="grupo__entreCallesClienteCobro">
                                            <div class="formulario__grupo-input">
                                                <input type="text" class="form-control formulario__input <?php $__errorArgs = ['entreCallesClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="entreCallesClienteCobro" value="<?php echo e(old('entreCallesClienteCobro')); ?>" name="entreCallesClienteCobro" placeholder="Entre calles">
                                                <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                            </div>
                                            <p class="formulario__input-error">Tiene que ser de maximo 50 caracteres, solo puede contener letras y numeros</p>

                                            <?php $__errorArgs = ['entreCallesClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-8" id="grupo__referenciasCasaClienteCobro">
                                            <div class="formulario__grupo-input">
                                                <input type="text" class="form-control formulario__input <?php $__errorArgs = ['referenciasCasaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="referenciasCasaClienteCobro" name="referenciasCasaClienteCobro" value="<?php echo e(old('referenciasCasaClienteCobro')); ?>" placeholder="Referencias del domicilio">
                                                <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                            </div>
                                            <p class="formulario__input-error">Tiene que ser de maximo 50 caracteres y solo puede contener letras</p>

                                            <?php $__errorArgs = ['referenciasCasaClienteCobro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="atrasP1" class="btn btn-secondary"><i class="fa-solid fa-circle-left fa-lg"></i> Atras</button>
                                    <button type="button" id="siguienteP3" class="btn btn-primary"><i class="fa-solid fa-circle-right"></i> Siguiente</button>
                                </div>

                            </div>
                            
                            <div id="cnp3" class="contenedorN3parte3">
                                <center>
                                    <h2>Datos del paquete</h1>
                                </center>
                                <div class="form-row">
                                    <div class="col-md-4 mb-3">
                                        <input type="text" class="form-control" id="nSolicitudRe" value="" readonly>

                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <input type="text" class="form-control " id="nContratoRe" value="" readonly>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col-md-5 mb-3" id="grupo__cvePaquete">
                                    <div class="formulario__grupo-input">
                                        <select class="form-control formulario__input <?php $__errorArgs = ['cvePaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="paquete" value="<?php echo e(old('cvePaquete')); ?>" name="cvePaquete" required>
                                            <option selected>Paquete...</option>
                                            <?php $__currentLoopData = $paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($paquete->cvePaquete); ?>"><?php echo e($paquete->nombrePaquete); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                        </div>
                                        <p class="formulario__input-error">La opción no es valida</p>
                                        <?php $__errorArgs = ['cvePaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="col-md-3 mb-3 " id="grupo__costoPaquete">
                                    <div class="formulario__grupo-input">
                                        <input type="text" class="form-control formulario__input <?php $__errorArgs = ['costoPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="precio" value="<?php echo e(old('costoPaquete')); ?>" readonly>
                                        <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <?php $__errorArgs = ['costoPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-4 " id="grupo__extraPaquete">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['extraPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="costoAdicional" value="<?php echo e(old('extraPaquete')); ?>" name="extraPaquete" placeholder="$$ adicional">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">solo puede tener maximo 8 digitos. El campo debe de tener el siguiente formato 5000.00, solo puede contener numeros y un punto</p>

                                        <?php $__errorArgs = ['extraPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row form-inline">
                                    <div class="col-md-8 mb-3" id="grupo__cveVendedor">
                                    <div class="formulario__grupo-input">
                                        <select id="vendedor" name="cveVendedor" class="form-control formulario__input <?php $__errorArgs = ['cveVendedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cveVendedor')); ?>" required>
                                            <option selected>*Vendedor...</option>
                                            <?php $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($vendedor->cveVendedor); ?>"><?php echo e($vendedor->nombreVendedor); ?> <?php echo e($vendedor-> apellidoPaternoVendedor); ?> <?php echo e($vendedor-> apellidoMaternoVendedor); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">La opción no es valida</p>
                                        <?php $__errorArgs = ['cveVendedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>
                                <div class="form-row form-inline">
                                    <div class="col-md-6 mb-3">
                                        <label for="fechaAfilacion">Fecha de afiliación</label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['fechaSolicitud'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fechaSolicitud" value="<?php echo e(old('fechaSolicitud')); ?>" id="fechaSolicitud">
                                        <?php $__errorArgs = ['fechaSolicitud'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="atrasP2" class="btn btn-secondary"><i class="fa-solid fa-circle-left fa-lg"></i> Atras</button>
                                    <button type="button" id="siguienteP4" class="btn btn-primary"><i class="fa-solid fa-circle-right"></i> Siguiente</button>
                                </div>
                            </div>
                            
                            <div id="cnp4" class="contenedorN3parte4">
                                <center>
                                    <h2>Datos del pago</h1>
                                </center>
                                <div class="form-row">
                                    <div class="form-group col-md-4" id="grupo__cveFormaPago">
                                    <div class="formulario__grupo-input">
                                        <select id="formaPago" name="cveFormaPago" value="<?php echo e(old('cveFormaPago')); ?>" class="form-control formulario__input <?php $__errorArgs = ['cveFormaPago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option selected>*Forma pago...</option>
                                            <?php $__currentLoopData = $formaPagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formaPago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($formaPago->cveFormaPago); ?>"><?php echo e($formaPago->nomFormaPago); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                        </div>
                                        <p class="formulario__input-error">La opción no es valida</p>
                                        <?php $__errorArgs = ['cveFormaPago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-4" id="grupo__cveCobrador">
                                    <div class="formulario__grupo-input">
                                        <select class="form-control formulario__input <?php $__errorArgs = ['cveCobrador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cveCobrador" value="<?php echo e(old('cveCobrador')); ?>" id="nombreCobrador" required>
                                            <option selected>*Cobrador...</option>
                                            <?php $__currentLoopData = $cobradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cobrador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cobrador->cveCobrador); ?>"><?php echo e($cobrador->nombreCobrador); ?> <?php echo e($cobrador-> apellidoPaternoCobrador); ?> <?php echo e($cobrador-> apellidoMaternoCobrador); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                        </div>
                                        <p class="formulario__input-error">La opción no es valida</p>
                                        <?php $__errorArgs = ['cveCobrador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col-md-4 mb-3" id="grupo__bonificacion">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['bonificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('bonificacion')); ?>" name="bonificacion" id="bonificacion" placeholder="Bonificación">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">solo puede tener maximo 8 digitos. El campo debe de tener el siguiente formato 5000.00, solo puede contener numeros y un punto</p>

                                        <?php $__errorArgs = ['bonificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-4 mb-3" id="grupo__inversionInicial">
                                        <div class="formulario__grupo-input">
                                            <input type="text" class="form-control formulario__input <?php $__errorArgs = ['inversionInicial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="inversionInicial" id="inversionInicial" value="<?php echo e(old('inversionInicial')); ?>" placeholder="Inversion incial">
                                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                                        </div>
                                        <p class="formulario__input-error">solo puede tener maximo 8 digitos. El campo debe de tener el siguiente formato 5000.00, solo puede contener numeros y un punto</p>

                                        <?php $__errorArgs = ['inversionInicial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
            
                                <div class="form-group">

                                    <button type="button" id="atrasP3" class="btn btn-secondary"><i class="fa-solid fa-circle-left fa-lg"></i> Atras</button>
                                    <button type="submit" class="btn btn-success">Guardar</button>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                    <div class="overlay" id="overlayEstado">
                        <div class="popup" id="popupEstado">
                            <h2>Agregar Estado</h2>
                            <form id="formGuardarEstado" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="form-group col-md-8">
                                        <input type="text" class="form-control" id="nomEstado" name="nomEstado" placeholder="Nombre" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="btn-cerrar-popup" class="btn btn-danger">Cancelar</button>
                                    <button type="button" id="btnGuardarEstado" class="btn btn-success">Guardar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="overlay" id="overlayMunicipio">
                        <div class="popup" id="popupMunicipio">
                            <h2>Agregar Municipio</h2>
                            <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-row ">
                                    <div class="form-group col-md-5">
                                        <select id="nombreEstadoNew" class="form-control" required>

                                            <?php $__currentLoopData = $estados->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($index); ?>">
                                                <?php echo e($estado); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-5">
                                        <input type="text" class="form-control" name="nombreMunicipioNew" id="nombreMunicipioNew" placeholder="Nombre" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="btn-cerrar-popupMunicipio" class="btn btn-danger">Cancelar</button>
                                    <button type="button" id="guardarMunicipio" class="btn btn-success">Guardar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="overlay" id="overlayColonia">
                        <div class="popup" id="popupColonia">
                            <h2>Agregar Colonia</h2>
                            <form action="" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row ">
                                    <div class="form-group col-md-5">

                                        <select id="municipioColoniaNew" name="municipioColoniaNew" class="form-control">
                                            <option>Municipio...</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-5">
                                        <input type="text" class="form-control" name="nomColoniaNew" id="nomColoniaNew" placeholder="Nombre">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="btn-cerrar-popupColonia" class="btn btn-danger">Cancelar</button>
                                    <button type="button" id="guardarColonia" class="btn btn-success">Guardar</button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>

        </div>

        <?php $__env->startSection('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/Ventas/AgregarClientesEstilos.js')); ?>" charset="utf8" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/Ventas/AgregarClienteAjax.js')); ?>" charset="utf8" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/Ventas/AgregarClienteValidaciones.js')); ?>" charset="utf8" type="text/javascript"></script>
       
        <?php $__env->stopSection(); ?>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ERFFUNJARCIE\ERProyect\resources\views/Ventas/agregarClientesVentas.blade.php ENDPATH**/ ?>